import pygame
import random

pygame.init()

WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ball Survival")

clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 200, 255)
RED = (255, 0, 0)

paddle = pygame.Rect(350, 550, 120, 15)

ball_x = 400
ball_y = 300
ball_radius = 10

ball_speed_x = 5
ball_speed_y = -5

score = 0

font = pygame.font.SysFont(None, 36)

obstacles = []

for i in range(5):
    obstacles.append(
        pygame.Rect(
            random.randint(50, 700),
            random.randint(50, 250),
            80,
            20
        )
    )

running = True

while running:

    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        paddle.x -= 8

    if keys[pygame.K_RIGHT]:
        paddle.x += 8

    paddle.x = max(0, min(WIDTH - paddle.width, paddle.x))

    ball_x += ball_speed_x
    ball_y += ball_speed_y

    if ball_x <= ball_radius or ball_x >= WIDTH - ball_radius:
        ball_speed_x *= -1

    if ball_y <= ball_radius:
        ball_speed_y *= -1

    ball_rect = pygame.Rect(
        ball_x - ball_radius,
        ball_y - ball_radius,
        ball_radius * 2,
        ball_radius * 2
    )

    if ball_rect.colliderect(paddle):
        ball_speed_y *= -1

    for obstacle in obstacles:
        if ball_rect.colliderect(obstacle):
            ball_speed_y *= -1

    if ball_y > HEIGHT:
        running = False

    score += 1

    if score % 1000 == 0:
        ball_speed_x *= 1.1
        ball_speed_y *= 1.1

    screen.fill(BLACK)

    pygame.draw.rect(screen, BLUE, paddle)

    pygame.draw.circle(
        screen,
        WHITE,
        (int(ball_x), int(ball_y)),
        ball_radius
    )

    for obstacle in obstacles:
        pygame.draw.rect(screen, RED, obstacle)

    score_text = font.render(
        f"Score: {score}",
        True,
        WHITE
    )

    screen.blit(score_text, (10, 10))

    pygame.display.flip()

pygame.quit()